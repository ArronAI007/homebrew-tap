// LLM Course Demo - Main Logic

let pyodide = null;
let pyodideReady = false;

// Initialize Pyodide on demand
async function initPyodide() {
    if (pyodideReady) return;
    try {
        pyodide = await loadPyodide();
        await pyodide.loadPackage("numpy");
        pyodideReady = true;
        document.getElementById('pyodideLoading')?.classList.add('hidden');
        console.log('Pyodide ready!');
    } catch (err) {
        console.error('Failed to load Pyodide:', err);
        throw new Error('Python 环境加载失败，请检查网络后刷新重试');
    }
}

// Run Python code (lazy-load Pyodide on first click)
async function runCode(codeId) {
    const editor = document.getElementById(codeId);
    const outputDiv = document.getElementById('output-' + codeId);
    const btn = document.querySelector(`button[data-codeid="${codeId}"]`);
    const code = editor.value;

    // Lazy-load Pyodide if not ready
    if (!pyodideReady) {
        btn.disabled = true;
        btn.textContent = '⏳ 加载环境中...';
        outputDiv.innerHTML = '<div class="output-content">正在加载 Python 运行环境，首次约需 5-10 秒...</div>';
        try {
            await initPyodide();
        } catch (err) {
            outputDiv.innerHTML = `<div class="output-error">${escapeHtml(err.message)}</div>`;
            btn.disabled = false;
            btn.textContent = '▶ 运行代码';
            return;
        }
    }

    btn.disabled = true;
    btn.textContent = '⏳ 运行中...';
    outputDiv.innerHTML = '<div class="output-content">运行中...</div>';

    try {
        const captureCode = `
import sys
from io import StringIO
_output = StringIO()
sys.stdout = _output
sys.stderr = _output

${code}

sys.stdout = sys.__stdout__
sys.stderr = sys.__stderr__
_output.getvalue()
`;
        const result = await pyodide.runPythonAsync(captureCode);
        outputDiv.innerHTML = `<div class="output-content">${escapeHtml(result)}</div>`;
    } catch (err) {
        outputDiv.innerHTML = `<div class="output-error">${escapeHtml(err.toString())}</div>`;
    } finally {
        btn.disabled = false;
        btn.textContent = '▶ 运行代码';
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Video Player
function playVideo(containerId) {
    const container = document.getElementById(containerId);
    const overlay = container.querySelector('.video-overlay');
    const video = container.querySelector('video');

    if (overlay) overlay.style.display = 'none';
    if (video) {
        video.setAttribute('controls', 'true');
        // For demo: show a message since we don't have a real video source
        if (!video.querySelector('source')?.getAttribute('src')) {
            container.innerHTML = `
                <div style="display:flex;align-items:center;justify-content:center;height:100%;color:white;flex-direction:column;gap:1rem;background:#1a202c;">
                    <div style="font-size:3rem">🎬</div>
                    <div style="font-size:1.1rem">此处为视频演示占位</div>
                    <div style="font-size:0.9rem;opacity:0.7">实际课程中可嵌入本地视频或 Bilibili/YouTube iframe</div>
                </div>
            `;
            saveProgress('lesson1', 50); // auto progress on video play
            return;
        }
        video.play();
    }
    saveProgress('lesson1', 50);
}

// Mark lesson complete
function markComplete(lessonId) {
    saveProgress(lessonId, 100);
    const btn = document.querySelector(`button[data-lesson="${lessonId}"]`);
    if (btn) {
        btn.textContent = '✅ 已完成';
        btn.disabled = true;
        btn.style.background = '#6b7280';
    }
}

// Lesson navigation
function showLesson(lessonId) {
    document.querySelectorAll('.lesson').forEach(l => l.classList.remove('active'));
    const target = document.getElementById(lessonId);
    if (target) target.classList.add('active');

    document.querySelectorAll('.lesson-list li').forEach(li => li.classList.remove('active'));
    const link = document.querySelector(`.lesson-list a[href="#${lessonId}"]`);
    if (link) link.parentElement.classList.add('active');

    if (window.innerWidth <= 768) {
        document.getElementById('sidebar').classList.remove('open');
    }
    window.scrollTo(0, 0);
}

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.run-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            const codeId = btn.getAttribute('data-codeid');
            runCode(codeId);
        });
    });

    document.querySelectorAll('.lesson-list a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const href = link.getAttribute('href');
            showLesson(href.substring(1));
        });
    });

    document.getElementById('menuToggle')?.addEventListener('click', () => {
        document.getElementById('sidebar').classList.toggle('open');
    });

    document.getElementById('loginBtn')?.addEventListener('click', openModal);
});
