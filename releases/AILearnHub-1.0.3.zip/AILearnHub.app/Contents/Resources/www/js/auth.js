// auth.js - Authentication & Progress Module

const API_BASE = 'http://localhost:8000';
const TOKEN_KEY = 'ail_token';
const LOCAL_PROGRESS_KEY = 'ail_progress';

let authMode = 'login'; // 'login' or 'register'

// ========== Token Management ==========
function getToken() {
    return localStorage.getItem(TOKEN_KEY);
}

function setToken(token) {
    localStorage.setItem(TOKEN_KEY, token);
}

function clearToken() {
    localStorage.removeItem(TOKEN_KEY);
}

// ========== API Helpers ==========
function isBackendOffline(err) {
    return err.message === 'Failed to fetch' ||
           err.message.includes('NetworkError') ||
           err.message.includes('net::ERR_CONNECTION_REFUSED');
}

async function apiPost(path, body, useAuth = false) {
    const opts = {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' }
    };
    if (body) opts.body = JSON.stringify(body);
    if (useAuth) {
        const token = getToken();
        if (token) opts.headers['Authorization'] = `Bearer ${token}`;
    }
    try {
        const res = await fetch(`${API_BASE}${path}`, opts);
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.detail || `请求失败: ${res.status}`);
        return data;
    } catch (err) {
        if (isBackendOffline(err)) {
            throw new Error('后端服务未启动，请先在终端执行：cd backend && uvicorn main:app --reload');
        }
        throw err;
    }
}

async function apiGet(path, useAuth = true) {
    const opts = { headers: {} };
    if (useAuth) {
        const token = getToken();
        if (token) opts.headers['Authorization'] = `Bearer ${token}`;
    }
    try {
        const res = await fetch(`${API_BASE}${path}`, opts);
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.detail || `请求失败: ${res.status}`);
        return data;
    } catch (err) {
        if (isBackendOffline(err)) {
            throw new Error('后端服务未启动，请先在终端执行：cd backend && uvicorn main:app --reload');
        }
        throw err;
    }
}

// ========== Auth Actions ==========
async function login(username, password) {
    const data = await apiPost('/api/auth/login', { username, password });
    setToken(data.access_token);
    updateAuthUI();
    closeModal();
    loadProgressFromServer();
    return data;
}

async function register(username, password) {
    await apiPost('/api/auth/register', { username, password });
    // Auto login after register
    return login(username, password);
}

function logout() {
    clearToken();
    updateAuthUI();
    renderProgressBars({});
}

// ========== UI Updates ==========
function updateAuthUI() {
    const section = document.getElementById('authSection');
    const token = getToken();
    if (token) {
        // Decode JWT payload to get username (basic)
        let username = '用户';
        try {
            const payload = JSON.parse(atob(token.split('.')[1]));
            username = payload.sub || '用户';
        } catch (e) {}
        section.innerHTML = `
            <div class="user-menu">
                <span class="user-name">👤 ${username}</span>
                <div class="user-dropdown">
                    <a href="#" onclick="logout(); return false;">退出登录</a>
                </div>
            </div>
        `;
    } else {
        section.innerHTML = `<button class="btn btn-outline" id="loginBtn" onclick="openModal()">登录 / 注册</button>`;
    }
}

// ========== Modal Logic ==========
function openModal() {
    document.getElementById('loginModal').classList.add('active');
    document.getElementById('authError').textContent = '';
}

function closeModal() {
    document.getElementById('loginModal').classList.remove('active');
}

function toggleAuthMode() {
    authMode = authMode === 'login' ? 'register' : 'login';
    document.getElementById('modalTitle').textContent = authMode === 'login' ? '登录' : '注册';
    document.getElementById('authSubmitBtn').textContent = authMode === 'login' ? '登录' : '注册';
    document.getElementById('switchText').textContent = authMode === 'login' ? '还没有账号？' : '已有账号？';
    document.getElementById('switchLink').textContent = authMode === 'login' ? '立即注册' : '立即登录';
    document.getElementById('authError').textContent = '';
}

async function handleAuthSubmit(e) {
    e.preventDefault();
    const username = document.getElementById('authUsername').value.trim();
    const password = document.getElementById('authPassword').value;
    const errorDiv = document.getElementById('authError');
    errorDiv.textContent = '';

    try {
        if (authMode === 'login') {
            await login(username, password);
        } else {
            await register(username, password);
        }
    } catch (err) {
        errorDiv.textContent = err.message;
    }
    return false;
}

// ========== Progress Management ==========
function getLocalProgress() {
    try {
        return JSON.parse(localStorage.getItem(LOCAL_PROGRESS_KEY) || '{}');
    } catch (e) {
        return {};
    }
}

function setLocalProgress(progress) {
    localStorage.setItem(LOCAL_PROGRESS_KEY, JSON.stringify(progress));
}

async function saveProgress(lessonId, percent) {
    const progress = getLocalProgress();
    progress[lessonId] = Math.max(progress[lessonId] || 0, percent);
    setLocalProgress(progress);

    if (getToken()) {
        try {
            await apiPost('/api/progress', { lesson_id: lessonId, percent_complete: percent }, true);
        } catch (err) {
            console.warn('同步进度到服务器失败:', err);
        }
    }
    renderProgressBars(progress);
}

async function getProgress() {
    if (getToken()) {
        try {
            const data = await apiGet('/api/progress');
            const serverProgress = {};
            (data.progress || []).forEach(p => {
                serverProgress[p.lesson_id] = p.percent_complete;
            });
            // Merge server progress into local
            const local = getLocalProgress();
            const merged = { ...local, ...serverProgress };
            setLocalProgress(merged);
            return merged;
        } catch (err) {
            console.warn('从服务器获取进度失败:', err);
        }
    }
    return getLocalProgress();
}

function renderProgressBars(progress) {
    ['lesson1', 'lesson2', 'lesson3', 'lesson4', 'lesson5', 'lesson6', 'lesson7', 'lesson8'].forEach(id => {
        const bar = document.getElementById(`progress-${id}`);
        if (bar) {
            const pct = progress[id] || 0;
            bar.style.width = `${pct}%`;
        }
        const status = document.getElementById(`status-${id}`);
        if (status) {
            const pct = progress[id] || 0;
            status.textContent = pct >= 100 ? '✅ 已完成' : (pct > 0 ? `${pct}% 已完成` : '');
        }
    });
}

async function loadProgressFromServer() {
    const progress = await getProgress();
    renderProgressBars(progress);
}

// ========== Backend Model Inference ==========
async function runBackendModel() {
    const prompt = document.getElementById('modelPrompt').value.trim();
    const resultDiv = document.getElementById('modelResult');
    if (!prompt) {
        resultDiv.innerHTML = '<span class="output-error">请输入 Prompt</span>';
        return;
    }
    resultDiv.innerHTML = '<em>🔄 正在调用 GPT-2 模型，请稍候（首次加载需下载约 500MB 模型）...</em>';
    try {
        const data = await apiPost('/api/model/run', { prompt, max_length: 50 });
        resultDiv.innerHTML = `<strong>生成结果：</strong><br><pre>${escapeHtml(data.result)}</pre>`;
    } catch (err) {
        resultDiv.innerHTML = `<span class="output-error">调用失败: ${escapeHtml(err.message)}<br>请确保后端服务已启动: <code>cd backend && uvicorn main:app --reload</code></span>`;
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// ========== Init ==========
document.addEventListener('DOMContentLoaded', () => {
    updateAuthUI();
    loadProgressFromServer();

    // Close modal on outside click
    document.getElementById('loginModal')?.addEventListener('click', (e) => {
        if (e.target.id === 'loginModal') closeModal();
    });
});
