# AILearnHub — UI 设计规范

> 版本: v1.0  
> 日期: 2026-05-11  
> 适用: Web App (Desktop + Tablet + Mobile)

---

## 1. 设计原则

### 1.1 核心定位
AILearnHub 是面向开发者的大模型技术学习平台。设计需要传递：
- **专业感**：代码、终端、数据可视化的视觉语言
- **沉浸感**：学习时不被 UI 干扰，内容优先
- **科技感**：暗色主题为主，霓虹蓝/紫作为点缀，呼应 AI/大模型主题

### 1.2 设计方向
**"Dark Terminal Luxury"** — 深色终端奢华风

- 深色背景为主，减轻长时间学习的眼部疲劳
- 终端绿/蓝作为高亮色，营造开发者熟悉的环境
- 玻璃拟态（Glassmorphism）用于卡片和弹层，增加层次
- 数据可视化元素（进度条、图表）使用渐变霓虹色

### 1.3 设计禁忌（Anti-Template Policy）
- 不采用默认的 Bootstrap/Tailwind 模板样式
- 不使用统一圆角和阴影
- 不使用安全灰白配色
- 不使用千篇一律的 Dashboard 布局

---

## 2. 色彩系统

### 2.1 暗色主题（默认）

```css
:root {
  /* 背景层 */
  --bg-primary: #0a0e17;      /* 主背景：深蓝黑 */
  --bg-secondary: #111827;    /* 次级背景：卡片、侧边栏 */
  --bg-tertiary: #1f2937;     /* 三级背景：hover、输入框 */
  --bg-elevated: #374151;     /* 浮层背景：弹窗、下拉 */
  
  /* 文字 */
  --text-primary: #f9fafb;    /* 主文字：标题 */
  --text-secondary: #9ca3af;  /* 次级文字：描述 */
  --text-muted: #6b7280;      /* 弱化文字：时间戳 */
  --text-inverse: #111827;    /* 反色文字：按钮上 */
  
  /* 主色调：霓虹蓝 */
  --accent-primary: #3b82f6;
  --accent-primary-hover: #2563eb;
  --accent-primary-glow: rgba(59, 130, 246, 0.3);
  
  /* 辅助色：紫 */
  --accent-secondary: #8b5cf6;
  --accent-secondary-hover: #7c3aed;
  
  /* 成功/警告/错误 */
  --success: #10b981;
  --warning: #f59e0b;
  --error: #ef4444;
  --info: #06b6d4;
  
  /* 代码高亮 */
  --code-bg: #1e1e2e;
  --code-border: #313244;
}
```

### 2.2 浅色主题（可选切换）

```css
[data-theme="light"] {
  --bg-primary: #fafafa;
  --bg-secondary: #ffffff;
  --bg-tertiary: #f3f4f6;
  --bg-elevated: #e5e7eb;
  
  --text-primary: #111827;
  --text-secondary: #4b5563;
  --text-muted: #9ca3af;
  --text-inverse: #ffffff;
  
  --code-bg: #f8f9fa;
  --code-border: #e5e7eb;
}
```

### 2.3 渐变色

```css
/* 主按钮渐变 */
--gradient-primary: linear-gradient(135deg, #3b82f6 0%, #8b5cf6 100%);

/* Hero 区域背景 */
--gradient-hero: linear-gradient(180deg, #0a0e17 0%, #111827 50%, #1e1b4b 100%);

/* 进度条 */
--gradient-progress: linear-gradient(90deg, #3b82f6 0%, #8b5cf6 50%, #ec4899 100%);

/* 霓虹光晕 */
--glow-blue: 0 0 20px rgba(59, 130, 246, 0.4);
--glow-purple: 0 0 20px rgba(139, 92, 246, 0.4);
```

### 2.4 语义色使用

| 场景 | 颜色 | Token |
|------|------|-------|
| 免费标签 | 翠绿 | `--success` |
| 付费/Pro标签 | 紫 | `--accent-secondary` |
| 学习进度 | 蓝到紫渐变 | `--gradient-progress` |
| 代码执行成功 | 绿 | `--success` |
| 代码执行错误 | 红 | `--error` |
| 警告提示 | 橙 | `--warning` |
| Notebook 单元格边框 | 蓝 | `--accent-primary` |

---

## 3. 字体排版

### 3.1 字体栈

```css
:root {
  /* 中文优先：适合技术内容的现代无衬线字体 */
  --font-sans: "Inter", "PingFang SC", "Hiragino Sans GB", "Microsoft YaHei", sans-serif;
  
  /* 代码字体 */
  --font-mono: "JetBrains Mono", "Fira Code", "SF Mono", "Cascadia Code", monospace;
  
  /* 标题字体（可选，用于 Hero 大标题） */
  --font-display: "Inter", "PingFang SC", sans-serif;
}
```

### 3.2 字号体系

| 级别 | 大小 | 字重 | 行高 | 用途 |
|------|------|------|------|------|
| Display | clamp(2.5rem, 5vw, 4rem) | 800 | 1.1 | Hero 主标题 |
| H1 | 2.25rem (36px) | 700 | 1.2 | 页面标题 |
| H2 | 1.875rem (30px) | 600 | 1.3 | 区块标题 |
| H3 | 1.5rem (24px) | 600 | 1.4 | 卡片标题 |
| H4 | 1.25rem (20px) | 500 | 1.5 | 小标题 |
| Body | 1rem (16px) | 400 | 1.75 | 正文 |
| Small | 0.875rem (14px) | 400 | 1.5 | 辅助文字 |
| Caption | 0.75rem (12px) | 500 | 1.5 | 标签、时间 |
| Code | 0.875rem (14px) | 400 | 1.7 | 代码块 |

### 3.3 排版规范

- 标题使用 `letter-spacing: -0.02em` 增强紧凑感
- 代码块使用 `--font-mono`，背景 `--code-bg`，边框 `--code-border`
- 行内代码：浅蓝背景 + 深蓝文字，圆角 4px
- 正文段落最大宽度 `65ch`，保证可读性

---

## 4. 间距与布局

### 4.1 间距系统

基于 4px 的网格系统：

```css
--space-1: 0.25rem;   /* 4px */
--space-2: 0.5rem;    /* 8px */
--space-3: 0.75rem;   /* 12px */
--space-4: 1rem;      /* 16px */
--space-5: 1.25rem;   /* 20px */
--space-6: 1.5rem;    /* 24px */
--space-8: 2rem;      /* 32px */
--space-10: 2.5rem;   /* 40px */
--space-12: 3rem;     /* 48px */
--space-16: 4rem;     /* 64px */
--space-20: 5rem;     /* 80px */
--space-24: 6rem;     /* 96px */
```

### 4.2 布局规范

#### 栅格系统
- 12列栅格
- 列间距 (gap): 24px
- 容器最大宽度: 1280px
- 移动端边距: 16px → 24px（平板）→ 32px（桌面）

#### 页面结构
```
┌──────────────────────────────────────┐
│            Navbar (64px)             │
├──────────┬───────────────────────────┤
│          │                           │
│ Sidebar  │        Main Content       │
│ (240px)  │        (flex: 1)          │
│          │                           │
└──────────┴───────────────────────────┘
```

- 学习页面：左侧课程目录（可折叠），右侧内容区
- 管理后台：顶部导航 + 左侧菜单 + 右侧内容

---

## 5. 组件设计规范

### 5.1 按钮 (Button)

#### 主按钮 (Primary)
```css
.btn-primary {
  background: var(--gradient-primary);
  color: var(--text-inverse);
  padding: 0.625rem 1.5rem;
  border-radius: 0.5rem;
  font-weight: 600;
  font-size: 0.875rem;
  border: none;
  cursor: pointer;
  transition: all 0.2s ease;
  box-shadow: var(--glow-blue);
}
.btn-primary:hover {
  transform: translateY(-1px);
  box-shadow: 0 0 30px rgba(59, 130, 246, 0.5);
}
```

#### 次级按钮 (Secondary)
```css
.btn-secondary {
  background: transparent;
  color: var(--text-primary);
  padding: 0.625rem 1.5rem;
  border-radius: 0.5rem;
  font-weight: 600;
  border: 1px solid var(--bg-elevated);
  transition: all 0.2s ease;
}
.btn-secondary:hover {
  background: var(--bg-tertiary);
  border-color: var(--accent-primary);
}
```

#### 幽灵按钮 (Ghost)
```css
.btn-ghost {
  background: transparent;
  color: var(--text-secondary);
  padding: 0.5rem 1rem;
  border: none;
}
.btn-ghost:hover {
  color: var(--text-primary);
  background: var(--bg-tertiary);
}
```

### 5.2 卡片 (Card)

#### 课程卡片
```css
.course-card {
  background: var(--bg-secondary);
  border: 1px solid rgba(255, 255, 255, 0.05);
  border-radius: 1rem;
  overflow: hidden;
  transition: all 0.3s ease;
}
.course-card:hover {
  transform: translateY(-4px);
  border-color: var(--accent-primary);
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4), var(--glow-blue);
}
```

- 封面图：宽高比 16:9，顶部圆角继承卡片
- 内容区：padding 20px
- 标签：绝对定位在封面图右上角
- 底部：价格和操作按钮

#### 数据卡片（Dashboard）
```css
.stat-card {
  background: linear-gradient(135deg, rgba(59, 130, 246, 0.1) 0%, rgba(139, 92, 246, 0.1) 100%);
  border: 1px solid rgba(59, 130, 246, 0.2);
  border-radius: 1rem;
  padding: 1.5rem;
}
```

### 5.3 导航 (Navigation)

#### 顶部导航
- 高度: 64px
- 背景: `rgba(10, 14, 23, 0.8)` + `backdrop-filter: blur(12px)`
- 底部边框: 1px solid rgba(255,255,255,0.05)
- Logo + 导航链接 + 搜索框 + 用户菜单

#### 侧边导航（学习页）
- 宽度: 280px（桌面），可折叠
- 背景: `--bg-secondary`
- 章节折叠/展开
- 课时状态指示：已完成（绿点）、进行中（蓝条）、未开始（灰点）

### 5.4 输入框 (Input)

```css
.input {
  background: var(--bg-tertiary);
  border: 1px solid var(--bg-elevated);
  border-radius: 0.5rem;
  padding: 0.625rem 1rem;
  color: var(--text-primary);
  font-size: 0.875rem;
  transition: all 0.2s ease;
}
.input:focus {
  outline: none;
  border-color: var(--accent-primary);
  box-shadow: 0 0 0 3px var(--accent-primary-glow);
}
```

### 5.5 标签/徽章 (Badge)

| 类型 | 背景 | 文字 | 使用场景 |
|------|------|------|----------|
| 免费 | `rgba(16, 185, 129, 0.15)` | `#10b981` | 免费课程 |
| Pro | `rgba(139, 92, 246, 0.15)` | `#8b5cf6` | 付费课程 |
| 热门 | `rgba(245, 158, 11, 0.15)` | `#f59e0b` | 热门标签 |
| 新课 | `rgba(59, 130, 246, 0.15)` | `#3b82f6` | 新上架 |
| 初级 | `rgba(6, 182, 212, 0.15)` | `#06b6d4` | 难度标签 |
| 高级 | `rgba(239, 68, 68, 0.15)` | `#ef4444` | 难度标签 |

### 5.6 代码块与 Notebook 单元格

#### 代码块
```css
.code-block {
  background: var(--code-bg);
  border: 1px solid var(--code-border);
  border-radius: 0.75rem;
  font-family: var(--font-mono);
  font-size: 0.875rem;
  line-height: 1.7;
}
.code-block-header {
  background: rgba(255,255,255,0.03);
  padding: 0.5rem 1rem;
  border-bottom: 1px solid var(--code-border);
  display: flex;
  justify-content: space-between;
  align-items: center;
}
```

#### Notebook 单元格
```css
.notebook-cell {
  border: 2px solid var(--code-border);
  border-radius: 0.5rem;
  margin-bottom: 1rem;
  transition: border-color 0.2s ease;
}
.notebook-cell:hover {
  border-color: var(--accent-primary);
}
.notebook-cell.executing {
  border-color: var(--warning);
  animation: pulse 1.5s infinite;
}
.notebook-cell.success {
  border-color: var(--success);
}
.notebook-cell.error {
  border-color: var(--error);
}
```

### 5.7 进度条 (Progress)

```css
.progress-bar {
  height: 6px;
  background: var(--bg-tertiary);
  border-radius: 3px;
  overflow: hidden;
}
.progress-bar-fill {
  height: 100%;
  background: var(--gradient-progress);
  border-radius: 3px;
  transition: width 0.5s ease;
}
```

### 5.8 模态框/弹窗 (Modal)

```css
.modal-overlay {
  background: rgba(0, 0, 0, 0.7);
  backdrop-filter: blur(4px);
}
.modal-content {
  background: var(--bg-secondary);
  border: 1px solid rgba(255,255,255,0.05);
  border-radius: 1rem;
  box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
}
```

### 5.9 Toast 通知

```css
.toast {
  background: var(--bg-secondary);
  border: 1px solid rgba(255,255,255,0.05);
  border-radius: 0.75rem;
  padding: 1rem 1.25rem;
  box-shadow: 0 10px 30px rgba(0,0,0,0.3);
}
.toast-success { border-left: 4px solid var(--success); }
.toast-error { border-left: 4px solid var(--error); }
.toast-info { border-left: 4px solid var(--info); }
```

---

## 6. 页面结构规范

### 6.1 首页 (Landing)

```
┌──────────────────────────────────────┐
│  Navbar                              │
├──────────────────────────────────────┤
│  Hero Section                        │
│  - 大标题 + 副标题                    │
│  - CTA 按钮                          │
│  - 装饰性代码片段/终端动画             │
├──────────────────────────────────────┤
│  Stats Bar（信任背书）                │
│  - 学员数 | 课程数 | 满意度           │
├──────────────────────────────────────┤
│  Featured Courses（精选课程）         │
│  - 分类标签筛选                       │
│  - 课程卡片网格 (3列桌面/2列平板/1列手机) │
├──────────────────────────────────────┤
│  How It Works（学习流程）             │
│  - 3-4步流程，图标+文字               │
├──────────────────────────────────────┤
│  Testimonials（学员评价）             │
├──────────────────────────────────────┤
│  CTA Section（底部转化）              │
├──────────────────────────────────────┤
│  Footer                              │
└──────────────────────────────────────┘
```

### 6.2 课程详情页 (Course Detail)

```
┌──────────────────────────────────────┐
│  Navbar                              │
├──────────────────────────────────────┤
│  Course Header                       │
│  - 封面图（全宽，渐变遮罩）            │
│  - 标题、描述、标签、讲师信息           │
│  - 价格 + 报名按钮                    │
├──────────────────────────────────────┤
│  Tabs: 课程大纲 | 课程介绍 | 评价     │
├──────────────────────────────────────┤
│  Content Area                        │
│  - 章节列表（可展开）                 │
│  - 每个课时显示类型图标+时长           │
└──────────────────────────────────────┘
```

### 6.3 学习页 (Learning)

```
┌──────────────────────────────────────┐
│  Navbar (compact)                    │
├──────────┬───────────────────────────┤
│          │  Breadcrumb               │
│  Course  ├───────────────────────────┤
│  Sidebar │  Lesson Content           │
│  - 章节   │  - Markdown 文档           │
│  - 课时   │  - 代码块                  │
│  (可折叠) │  - Notebook 单元格         │
│          ├───────────────────────────┤
│          │  Navigation Footer        │
│          │  上一课 | 进度 | 下一课     │
└──────────┴───────────────────────────┘
```

#### 学习页交互
- 侧边栏可折叠（移动端默认隐藏）
- 代码块支持复制、全屏
- Notebook 单元格支持运行、重置、清除输出
- 实时保存阅读位置和代码编辑状态

### 6.4 管理后台 (Admin Dashboard)

```
┌──────────────────────────────────────┐
│  Top Bar (Logo + Search + User)      │
├──────────┬───────────────────────────┤
│          │  Stats Cards Row          │
│  Sidebar │  (收入 | 用户 | 课程 | 订单) │
│  - 仪表盘 ├───────────────────────────┤
│  - 课程管理│  Charts / Tables          │
│  - 用户管理│                           │
│  - 订单管理├───────────────────────────┤
│  - 数据分析│  Data Table               │
│  - 设置   │  (分页、筛选、排序)         │
└──────────┴───────────────────────────┘
```

---

## 7. 动画与交互

### 7.1 过渡效果

```css
/* 标准过渡 */
--transition-fast: 150ms ease;
--transition-normal: 300ms ease;
--transition-slow: 500ms ease;

/* 缓动函数 */
--ease-out-expo: cubic-bezier(0.16, 1, 0.3, 1);
--ease-spring: cubic-bezier(0.34, 1.56, 0.64, 1);
```

### 7.2 微交互

| 元素 | 交互 | 效果 |
|------|------|------|
| 按钮 | Hover | 上移 1px + 增强阴影 |
| 卡片 | Hover | 上移 4px + 边框高亮 + 发光 |
| 链接 | Hover | 颜色变为 accent-primary |
| 输入框 | Focus | 蓝色边框 + 外发光 |
| 标签 | Hover | 背景透明度增加 |
| 课时项 | Hover | 左侧出现蓝色指示条 |
| 代码块 | Hover | 显示复制按钮 |

### 7.3 页面切换

- 路由切换：淡入淡出 200ms
- 内容加载：骨架屏 → 内容淡入
- 模态框：背景淡入 + 内容从下方滑入 300ms

### 7.4 加载状态

```css
.skeleton {
  background: linear-gradient(
    90deg,
    var(--bg-tertiary) 25%,
    var(--bg-elevated) 50%,
    var(--bg-tertiary) 75%
  );
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite;
  border-radius: 0.5rem;
}
```

### 7.5 Notebook 执行动画

```css
@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}
@keyframes spin {
  to { transform: rotate(360deg); }
}
```

- 执行中：单元格边框黄色脉冲动画
- 执行成功：边框绿色，显示输出
- 执行失败：边框红色，显示错误堆栈

---

## 8. 图标系统

使用 **Lucide React** 图标库，风格统一为：
- 线框风格（stroke-width: 1.5-2）
- 尺寸: 16px（小）、20px（默认）、24px（大）

常用图标映射：

| 场景 | 图标 |
|------|------|
| 课程 | `BookOpen` |
| 视频 | `PlayCircle` |
| 文档 | `FileText` |
| 代码/Notebook | `Terminal` |
| 完成 | `CheckCircle2` |
| 进行中 | `Loader2` (旋转) |
| 锁/付费 | `Lock` |
| 免费 | `Unlock` |
| 搜索 | `Search` |
| 用户 | `User` |
| 设置 | `Settings` |
| 退出 | `LogOut` |
| 菜单 | `Menu` |
| 折叠 | `ChevronLeft` |
| 展开 | `ChevronDown` |
| 代码执行 | `Play` |
| 代码停止 | `Square` |
| 复制 | `Copy` |
| 全屏 | `Maximize2` |
| 下载 | `Download` |
| 收藏 | `Bookmark` |
| 分享 | `Share2` |

---

## 9. 响应式断点

```css
/* Mobile First */
--screen-sm: 640px;   /* 小平板 */
--screen-md: 768px;   /* 平板 */
--screen-lg: 1024px;  /* 小桌面 */
--screen-xl: 1280px;  /* 标准桌面 */
--screen-2xl: 1536px; /* 大桌面 */
```

### 响应式规则

| 元素 | 桌面 | 平板 | 手机 |
|------|------|------|------|
| 课程网格 | 3列 | 2列 | 1列 |
| 学习页侧边栏 | 固定 280px | 可抽屉收起 | 抽屉收起 |
| 管理后台侧边栏 | 固定 240px | 可收起 | 抽屉收起 |
| 首页 Hero 标题 | 4rem | 3rem | 2.25rem |
| 容器边距 | 32px | 24px | 16px |
| 导航栏高度 | 64px | 64px | 56px |

---

## 10. 设计检查清单

在实现每个页面前，请确认：

- [ ] 深色主题为主，避免大面积浅色区域
- [ ] 使用渐变和霓虹色点缀，但不过度
- [ ] 卡片使用微妙的边框和 hover 发光效果
- [ ] 代码块和 Notebook 单元格有明确的视觉边界
- [ ] 学习进度使用渐变进度条
- [ ] 按钮有明确的 hover 反馈
- [ ] 文字层级清晰（标题/正文/辅助文字对比度足够）
- [ ] 所有图标使用统一的 Lucide 线框风格
- [ ] 动画仅用于增强体验，不干扰内容阅读
- [ ] 响应式布局在所有断点测试通过
