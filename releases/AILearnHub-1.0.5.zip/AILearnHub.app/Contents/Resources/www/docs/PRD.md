# AILearnHub — 大模型知识课程管理系统

## 产品需求文档 (PRD)

> 版本: v1.0  
> 日期: 2026-05-11  
> 状态: 设计阶段

---

## 1. 产品概述

### 1.1 产品定位
AILearnHub 是一个面向开发者和技术人员的大模型知识学习平台，提供结构化课程、可交互的 Jupyter Notebook 实验环境，以及免费 + 付费的内容分层体系。

### 1.2 核心目标
- **知识传递**：系统化的大模型技术课程体系（Prompt工程、RAG、微调、Agent等）
- **实践驱动**：内置可执行的 Jupyter Notebook，边学边练
- **商业闭环**：免费内容引流，付费课程变现，订阅制长期收益
- **社区沉淀**：学习记录、笔记分享、进度追踪

### 1.3 目标用户
| 用户角色 | 特征 | 需求 |
|---------|------|------|
| 免费用户 | 初级开发者、AI爱好者 | 免费基础课程、试用体验 |
| 付费用户 | 中高级开发者、工程师 | 高级课程、完整Notebook环境、证书 |
| 管理员 | 内容运营、技术专家 | 课程创建、用户管理、数据分析 |

---

## 2. 功能模块

### 2.1 课程管理系统

#### 课程结构
```
课程 (Course)
├── 章节 (Chapter)
│   ├── 课时 (Lesson)
│   │   ├── 知识文档 (Markdown/HTML)
│   │   ├── 代码练习 (Jupyter Notebook)
│   │   ├── 视频讲解 (可选)
│   │   └── 课后测验 (Quiz)
│   └── 章节测验
└── 课程项目 (Project)
```

#### 课程属性
| 字段 | 类型 | 说明 |
|------|------|------|
| title | string | 课程标题 |
| slug | string | URL友好标识 |
| description | text | 课程简介 |
| cover_image | image | 封面图 |
| difficulty | enum | 初级/中级/高级 |
| price | decimal | 价格（0表示免费） |
| is_published | boolean | 是否发布 |
| instructor | FK | 讲师 |
| category | FK | 分类 |
| tags | M2M | 标签 |
| duration | int | 预计学习时长(分钟) |
| prerequisites | text | 前置知识 |
| created_at | datetime | 创建时间 |
| updated_at | datetime | 更新时间 |

#### 管理员功能
- [ ] 创建/编辑/删除课程
- [ ] 章节和课时排序（拖拽）
- [ ] 上传知识文档（Markdown编辑器，支持LaTeX公式）
- [ ] 上传/编写 Jupyter Notebook (.ipynb)
- [ ] 设置课程价格或免费
- [ ] 课程预览（以用户视角查看）
- [ ] 课程发布/下架

### 2.2 用户系统

#### 用户模型
| 字段 | 类型 | 说明 |
|------|------|------|
| username | string | 用户名 |
| email | string | 邮箱（唯一） |
| password | hash | 加密密码 |
| avatar | image | 头像 |
| role | enum | admin/instructor/student |
| is_premium | boolean | 是否订阅会员 |
| premium_expires | datetime | 会员到期时间 |
| created_at | datetime | 注册时间 |

#### 功能点
- [ ] 邮箱注册/登录
- [ ] 密码重置
- [ ] 第三方登录（GitHub、Google）
- [ ] 个人资料编辑
- [ ] 学习进度仪表盘
- [ ] 我的课程（已购/收藏）
- [ ] 学习证书

### 2.3 学习系统

#### 核心功能
- [ ] **课程目录导航**：侧边栏显示课程大纲，标记已完成课时
- [ ] **知识文档阅读**：支持Markdown渲染、代码高亮、LaTeX公式
- [ ] **Notebook交互运行**：
  - 后端集成 JupyterHub 或自研沙箱
  - 支持代码单元格执行
  - 支持文件上传/下载
  - 支持环境变量和secret管理
  - 资源限制（CPU/内存/执行时间）
- [ ] **学习进度自动保存**：阅读位置、代码编辑状态
- [ ] **课后测验**：单选/多选/编程题
- [ ] **笔记功能**：高亮文本、添加笔记、导出
- [ ] **讨论区**：每课时下方留言讨论

#### 学习进度跟踪
| 字段 | 类型 | 说明 |
|------|------|------|
| user | FK | 用户 |
| lesson | FK | 课时 |
| status | enum | not_started/reading/completed |
| progress_percent | int | 进度百分比 |
| last_position | int | 最后阅读位置 |
| notebook_state | JSON | Notebook单元格状态 |
| completed_at | datetime | 完成时间 |

### 2.4 支付系统

#### 定价模式
- **免费课程**：price = 0，所有人可访问
- **单课购买**：一次性购买单门课程
- **会员订阅**：月付/年付，解锁所有付费内容

#### 功能点
- [ ] 课程购买（Stripe/支付宝/微信支付）
- [ ] 会员订阅管理（升级/降级/取消）
- [ ] 订单历史
- [ ] 发票申请
- [ ] 优惠券/折扣码
- [ ] 退款流程

#### 订单模型
| 字段 | 类型 | 说明 |
|------|------|------|
| user | FK | 用户 |
| order_type | enum | course/subscription |
| course | FK | 课程（单课购买时） |
| amount | decimal | 金额 |
| currency | string | 货币 |
| status | enum | pending/paid/failed/refunded |
| payment_method | string | 支付方式 |
| transaction_id | string | 第三方交易ID |
| created_at | datetime | 创建时间 |

### 2.5 管理后台

#### 仪表盘
- [ ] 用户统计（注册数、活跃数、付费转化率）
- [ ] 课程统计（最受欢迎课程、完课率）
- [ ] 收入统计（日/周/月收入、订阅趋势）
- [ ] 最近订单

#### 课程管理
- [ ] 课程列表（搜索、筛选、排序）
- [ ] 课程编辑（富文本编辑器 + Notebook编辑器）
- [ ] 批量操作（上架/下架/删除）

#### 用户管理
- [ ] 用户列表（搜索、筛选）
- [ ] 用户详情（学习记录、订单记录）
- [ ] 权限管理（设为管理员/讲师）
- [ ] 用户消息通知

#### 财务管理
- [ ] 订单列表
- [ ] 退款处理
- [ ] 优惠券管理
- [ ] 收入报表导出

---

## 3. 数据库设计

### 3.1 ER图

```
User (1) ───< (N) Enrollment >─── (1) Course
User (1) ───< (N) Order >──────── (1) Course
User (1) ───< (N) LessonProgress >── (1) Lesson
User (1) ───< (N) Note >───────── (1) Lesson
User (1) ───< (N) Comment >────── (1) Lesson

Course (1) ──< (N) Chapter >─── (N) Lesson
Course (N) ──< (M) Category
Course (N) ──< (M) Tag

Lesson (1) ──< (N) QuizQuestion
```

### 3.2 核心模型

#### User
```python
class User(AbstractUser):
    email = models.EmailField(unique=True)
    avatar = models.ImageField(upload_to='avatars/', blank=True)
    role = models.CharField(max_length=20, choices=ROLES, default='student')
    is_premium = models.BooleanField(default=False)
    premium_expires = models.DateTimeField(null=True, blank=True)
    bio = models.TextField(blank=True)
    github_id = models.CharField(max_length=100, blank=True)
    google_id = models.CharField(max_length=100, blank=True)
```

#### Course
```python
class Course(models.Model):
    STATUS_CHOICES = [
        ('draft', '草稿'),
        ('published', '已发布'),
        ('archived', '已归档'),
    ]
    
    title = models.CharField(max_length=200)
    slug = models.SlugField(unique=True)
    description = models.TextField()
    cover_image = models.ImageField(upload_to='courses/covers/')
    difficulty = models.CharField(max_length=20, choices=DIFFICULTIES)
    price = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    original_price = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    instructor = models.ForeignKey(User, on_delete=models.SET_NULL, null=True)
    categories = models.ManyToManyField(Category)
    tags = models.ManyToManyField(Tag, blank=True)
    duration = models.PositiveIntegerField(help_text='预计学习时长(分钟)')
    prerequisites = models.TextField(blank=True)
    learning_outcomes = models.JSONField(default=list)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
```

#### Chapter
```python
class Chapter(models.Model):
    course = models.ForeignKey(Course, on_delete=models.CASCADE, related_name='chapters')
    title = models.CharField(max_length=200)
    order = models.PositiveIntegerField(default=0)
    description = models.TextField(blank=True)
```

#### Lesson
```python
class Lesson(models.Model):
    TYPE_CHOICES = [
        ('document', '知识文档'),
        ('notebook', '代码练习'),
        ('video', '视频讲解'),
        ('quiz', '课后测验'),
    ]
    
    chapter = models.ForeignKey(Chapter, on_delete=models.CASCADE, related_name='lessons')
    title = models.CharField(max_length=200)
    slug = models.SlugField()
    order = models.PositiveIntegerField(default=0)
    lesson_type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    content = models.TextField(help_text='Markdown内容')
    notebook_file = models.FileField(upload_to='notebooks/', blank=True, null=True)
    video_url = models.URLField(blank=True)
    duration = models.PositiveIntegerField(help_text='课时长度(分钟)', default=0)
    is_free_preview = models.BooleanField(default=False, help_text='免费试看')
```

#### Enrollment（课程注册/学习记录）
```python
class Enrollment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    status = models.CharField(max_length=20, choices=[('active','学习中'),('completed','已完成'),('expired','已过期')])
    progress = models.PositiveIntegerField(default=0)
    enrolled_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    expires_at = models.DateTimeField(null=True, blank=True)
```

#### LessonProgress
```python
class LessonProgress(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    lesson = models.ForeignKey(Lesson, on_delete=models.CASCADE)
    status = models.CharField(max_length=20, choices=[('not_started','未开始'),('reading','学习中'),('completed','已完成')])
    progress_percent = models.PositiveIntegerField(default=0)
    last_position = models.PositiveIntegerField(default=0)
    notebook_state = models.JSONField(default=dict, blank=True)
    started_at = models.DateTimeField(auto_now_add=True)
    completed_at = models.DateTimeField(null=True, blank=True)
```

#### Order
```python
class Order(models.Model):
    ORDER_TYPES = [('course', '单课'), ('subscription_monthly', '月度会员'), ('subscription_yearly', '年度会员')]
    STATUS_CHOICES = [('pending', '待支付'), ('paid', '已支付'), ('failed', '支付失败'), ('refunded', '已退款')]
    
    order_no = models.CharField(max_length=50, unique=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    order_type = models.CharField(max_length=30, choices=ORDER_TYPES)
    course = models.ForeignKey(Course, on_delete=models.SET_NULL, null=True, blank=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    currency = models.CharField(max_length=10, default='CNY')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    payment_method = models.CharField(max_length=50, blank=True)
    transaction_id = models.CharField(max_length=200, blank=True)
    paid_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
```

---

## 4. API 接口规范

### 4.1 RESTful API 设计

基础路径: `/api/v1/`

#### 认证相关
| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/auth/register/` | 用户注册 |
| POST | `/auth/login/` | 用户登录（JWT） |
| POST | `/auth/logout/` | 退出登录 |
| POST | `/auth/refresh/` | 刷新Token |
| POST | `/auth/password-reset/` | 密码重置 |
| POST | `/auth/github/` | GitHub登录 |

#### 课程相关
| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/courses/` | 课程列表（分页、筛选、搜索） |
| GET | `/courses/{slug}/` | 课程详情 |
| GET | `/courses/{slug}/chapters/` | 课程章节列表 |
| GET | `/courses/{slug}/lessons/{lesson_slug}/` | 课时详情 |
| POST | `/courses/{slug}/enroll/` | 报名课程（免费直接报名，付费跳转支付） |
| GET | `/categories/` | 课程分类 |
| GET | `/tags/` | 课程标签 |

#### 学习相关
| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/my-courses/` | 我的课程 |
| GET | `/my-progress/` | 学习进度 |
| POST | `/lessons/{id}/progress/` | 更新学习进度 |
| GET | `/lessons/{id}/notebook/` | 获取Notebook内容 |
| POST | `/lessons/{id}/notebook/execute/` | 执行Notebook单元格 |
| POST | `/lessons/{id}/notes/` | 添加笔记 |
| GET | `/lessons/{id}/comments/` | 获取讨论区留言 |
| POST | `/lessons/{id}/comments/` | 发表留言 |

#### 支付相关
| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/orders/` | 创建订单 |
| GET | `/orders/{order_no}/` | 订单详情 |
| POST | `/orders/{order_no}/pay/` | 发起支付 |
| POST | `/payments/webhook/` | 支付回调（Stripe/支付宝） |
| GET | `/subscriptions/` | 订阅信息 |
| POST | `/subscriptions/` | 创建订阅 |

#### 管理后台
| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/admin/dashboard/` | 仪表盘数据 |
| GET | `/admin/courses/` | 课程列表（管理） |
| POST | `/admin/courses/` | 创建课程 |
| PUT | `/admin/courses/{id}/` | 更新课程 |
| DELETE | `/admin/courses/{id}/` | 删除课程 |
| GET | `/admin/users/` | 用户列表 |
| GET | `/admin/orders/` | 订单列表 |
| GET | `/admin/analytics/` | 统计分析 |

### 4.2 响应格式

```json
{
  "success": true,
  "data": {},
  "message": "",
  "meta": {
    "page": 1,
    "page_size": 20,
    "total": 100
  }
}
```

错误响应:
```json
{
  "success": false,
  "error": {
    "code": "COURSE_NOT_FOUND",
    "message": "课程不存在"
  }
}
```

---

## 5. 非功能性需求

### 5.1 性能要求
- 页面首屏加载 < 2s
- API 响应时间 < 200ms（P95）
- Notebook 代码执行启动 < 5s
- 支持 1000+ 并发用户

### 5.2 安全要求
- 用户密码 bcrypt 加密
- JWT Token 过期机制
- API 限流（Rate Limiting）
- XSS/SQL注入防护
- Notebook 沙箱隔离（禁止网络访问、文件系统限制）
- 敏感操作审计日志

### 5.3 可用性要求
- 支持深色/浅色主题切换
- 响应式设计（适配桌面、平板、手机）
- 断网缓存（PWA）
- 无障碍支持（WCAG 2.1 AA）

### 5.4 Notebook 沙箱安全
- 容器化运行（Docker）
- CPU 限制：1核
- 内存限制：512MB
- 执行超时：30秒
- 禁止访问内网
- 临时文件自动清理

---

## 6. 技术架构

### 6.1 系统架构图

```
┌─────────────────────────────────────────────────────────────┐
│                        客户端层                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │   Web App    │  │   Mobile     │  │   Admin      │      │
│  │  (React)     │  │  (Responsive)│  │  (React)     │      │
│  └──────────────┘  └──────────────┘  └──────────────┘      │
└──────────────────────────┬──────────────────────────────────┘
                           │ HTTPS
┌──────────────────────────▼──────────────────────────────────┐
│                      网关层 (Nginx)                          │
└──────────────────────────┬──────────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                     应用服务层 (Django)                       │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐      │
│  │ 课程服务  │ │ 用户服务  │ │ 支付服务  │ │ 学习服务  │      │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘      │
└──────────────────────────┬──────────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                     数据层                                   │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐                    │
│  │PostgreSQL│ │  Redis   │ │  MinIO   │                    │
│  │ (主数据)  │ │ (缓存)   │ │ (对象存储)│                    │
│  └──────────┘ └──────────┘ └──────────┘                    │
└─────────────────────────────────────────────────────────────┘
                           │
┌──────────────────────────▼──────────────────────────────────┐
│                   Notebook执行层                             │
│  ┌──────────────────────────────────────────────┐          │
│  │         JupyterHub / Docker Sandbox          │          │
│  │   (Kubernetes / Docker Compose 编排)          │          │
│  └──────────────────────────────────────────────┘          │
└─────────────────────────────────────────────────────────────┘
```

### 6.2 技术栈

| 层级 | 技术选型 | 说明 |
|------|----------|------|
| 前端 | React 19 + TypeScript + Tailwind CSS | 现代化UI框架 |
| 状态管理 | Zustand | 轻量级状态管理 |
| 后端 | Django 5 + Django REST Framework | Python成熟Web框架 |
| 数据库 | PostgreSQL 16 | 关系型数据库 |
| 缓存 | Redis | Session、缓存、限流 |
| 对象存储 | MinIO / 阿里云OSS | 文件、图片、Notebook存储 |
| Notebook | JupyterHub + Docker | 代码执行环境 |
| 消息队列 | Celery + Redis | 异步任务、邮件发送 |
| 搜索 | Elasticsearch (可选) | 课程搜索 |
| 部署 | Docker + Docker Compose | 容器化部署 |

---

## 7. 项目里程碑

| 阶段 | 时间 | 交付物 |
|------|------|--------|
| Phase 1 | 第1-2周 | 需求确认、UI设计、数据库设计 |
| Phase 2 | 第3-5周 | 后端API开发（用户、课程、学习） |
| Phase 3 | 第6-8周 | 前端页面开发、Notebook集成 |
| Phase 4 | 第9-10周 | 支付系统、管理后台 |
| Phase 5 | 第11-12周 | 测试、优化、上线 |

---

## 8. 风险与应对

| 风险 | 影响 | 应对措施 |
|------|------|----------|
| Notebook沙箱安全 | 高 | 使用Docker隔离，限制资源，定期安全审计 |
| 高并发Notebook | 高 | K8s自动扩缩容，资源池预热 |
| 支付合规 | 中 | 接入合规支付通道，保留完整交易记录 |
| 内容盗版 | 中 | 内容加密传输，限制下载，水印 |

---

## 附录

### A. 课程分类示例
- 大模型基础（免费）
- Prompt工程（付费）
- RAG检索增强（付费）
- 模型微调与部署（付费）
- AI Agent开发（付费）
- 多模态大模型（付费）

### B. 免费 vs 付费内容策略
| 维度 | 免费 | 付费 |
|------|------|------|
| 课程数量 | 3-5门基础课 | 全部高级课程 |
| 课时内容 | 前30%试看 | 完整内容 |
| Notebook | 只读，不可执行 | 完整执行环境 |
| 证书 | 无 | 完成证书 |
| 社区支持 | 公开讨论区 | 1对1答疑 |
| 源码下载 | 不可下载 | 可下载 |
