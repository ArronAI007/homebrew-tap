// Notebook Laboratory - Lazy-load Starboard, default to JupyterLite iframe

const API_BASE = 'http://localhost:8000';
let StarboardEmbed = null;

// Pre-defined notebook templates
const NOTEBOOK_TEMPLATES = {
    attention: {
        cells: [
            {
                id: "cell-1",
                cellType: "markdown",
                textContent: "# 🔬 注意力机制实验\n\n在这个 Notebook 中，我们将从零开始用 NumPy 实现 **Scaled Dot-Product Attention**，这是 Transformer 的核心组件。"
            },
            {
                id: "cell-2",
                cellType: "markdown",
                textContent: "## 1. 准备数据\n\n首先创建 3 个词的嵌入向量："
            },
            {
                id: "cell-3",
                cellType: "python",
                textContent: "import numpy as np\n\n# 3 个词，每个词 4 维向量\nX = np.array([\n    [1.0, 0.2, 0.1, 0.5],   # \"我\"\n    [0.3, 1.0, 0.4, 0.2],   # \"喜欢\"\n    [0.1, 0.5, 1.0, 0.3]    # \"AI\"\n])\n\nprint(\"输入矩阵 X (3×4):\")\nprint(X)"
            },
            {
                id: "cell-4",
                cellType: "markdown",
                textContent: "## 2. 定义 Q, K, V 矩阵\n\n通过线性变换得到 Query、Key、Value："
            },
            {
                id: "cell-5",
                cellType: "python",
                textContent: "# 初始化权重矩阵 (4×4，为了简化)\nnp.random.seed(42)\nW_q = np.random.randn(4, 4) * 0.1\nW_k = np.random.randn(4, 4) * 0.1\nW_v = np.random.randn(4, 4) * 0.1\n\nQ = X @ W_q\nK = X @ W_k\nV = X @ W_v\n\nprint(\"Query 矩阵:\")\nprint(Q.round(3))"
            },
            {
                id: "cell-6",
                cellType: "markdown",
                textContent: "## 3. 计算注意力分数\n\n公式：\\(\\text{Attention}(Q,K,V) = \\text{softmax}\\left(\\frac{QK^T}{\\sqrt{d_k}}\\right)V\\)"
            },
            {
                id: "cell-7",
                cellType: "python",
                textContent: "def softmax(x):\n    exp_x = np.exp(x - np.max(x, axis=-1, keepdims=True))\n    return exp_x / np.sum(exp_x, axis=-1, keepdims=True)\n\nd_k = Q.shape[1]\nscores = Q @ K.T / np.sqrt(d_k)\nweights = softmax(scores)\noutput = weights @ V\n\nprint(\"注意力权重:\")\nprint(weights.round(3))\nprint(\"\\n输出矩阵:\")\nprint(output.round(3))"
            },
            {
                id: "cell-8",
                cellType: "markdown",
                textContent: "## ✅ 实验完成\n\n你已经手动实现了 Attention 的核心计算！在真实 Transformer 中，还会使用多头注意力（Multi-Head Attention）和掩码（Mask）等技巧。"
            }
        ]
    },
    nlp: {
        cells: [
            {
                id: "cell-1",
                cellType: "markdown",
                textContent: "# 📝 NLP 基础实验\n\n学习文本预处理的基础操作。"
            },
            {
                id: "cell-2",
                cellType: "python",
                textContent: "text = \"Hello, 大模型世界! NLP 很有趣。\"\n\n# 1. 按字符分词\nchar_tokens = list(text)\nprint(\"字符分词:\", char_tokens[:10], \"...\")\n\n# 2. 按空格分词\nword_tokens = text.split()\nprint(\"\\n空格分词:\", word_tokens)"
            },
            {
                id: "cell-3",
                cellType: "python",
                textContent: "# 3. 简单的词频统计\nfrom collections import Counter\n\nsentence = \"大模型 很 厉害 大模型 改变 世界 世界 很 精彩\"\nwords = sentence.split()\nfreq = Counter(words)\n\nprint(\"词频统计:\")\nfor word, count in freq.most_common():\n    print(f\"  {word}: {count}\")"
            },
            {
                id: "cell-4",
                cellType: "markdown",
                textContent: "## 练习\n\n尝试修改上面的代码，实现你自己的分词器！"
            }
        ]
    },
    empty: {
        cells: [
            {
                id: "cell-1",
                cellType: "markdown",
                textContent: "# 空白 Notebook\n\n点击下方的 **+** 按钮添加新的单元格，开始你的实验！"
            }
        ]
    }
};

let currentStarboard = null;

function buildNotebookContent(templateKey) {
    const template = NOTEBOOK_TEMPLATES[templateKey] || NOTEBOOK_TEMPLATES.empty;
    return JSON.stringify(template);
}

let liteMode = false;

function useLiteFallback(key) {
    liteMode = true;
    document.getElementById('nbLoading').classList.add('hidden');
    loadNotebookLite(key || 'attention');
}

function loadNotebookLite(key) {
    const container = document.getElementById('starboard-container');
    if (!container) return;
    container.innerHTML = '';

    const codeMap = {
        attention: `import numpy as np\n\nX = np.array([[1.0, 0.2, 0.1], [0.3, 1.0, 0.4], [0.1, 0.5, 1.0]])\nprint("词向量:", X)`,
        nlp: `text = "Hello, 大模型世界!"\nprint(list(text))`,
        empty: `print("Hello JupyterLite!")`
    };
    const code = encodeURIComponent(codeMap[key] || codeMap.empty);

    container.innerHTML = `
        <div style="padding:1rem 0;">
            <div style="margin-bottom:0.75rem;color:#718096;font-size:0.9rem;">
                💡 轻量版 JupyterLite（加载更快，支持 Python 代码运行）
            </div>
            <iframe
                src="https://jupyterlite.github.io/demo/repl/index.html?kernel=python&toolbar=1&code=${code}"
                width="100%"
                height="600px"
                style="border:1px solid #e2e8f0;border-radius:8px;"
                allow="fullscreen"
            ></iframe>
        </div>
    `;

    document.querySelectorAll('.lesson-list li').forEach(li => li.classList.remove('active'));
    document.querySelectorAll('.lesson-list a').forEach(link => {
        if (link.getAttribute('onclick')?.includes(`'${key}'`)) {
            link.parentElement.classList.add('active');
        }
    });
}

async function initStarboard() {
    // Default: use JupyterLite iframe (instant load)
    useLiteFallback();
}

async function loadFullNotebook(key) {
    key = key || 'attention';
    const container = document.getElementById('starboard-container');
    if (!container) return;

    const loading = document.getElementById('nbLoading');
    loading.classList.remove('hidden');
    loading.querySelector('p').textContent = '正在加载 Starboard Notebook...';
    loading.querySelector('.loading-hint').textContent = '首次加载约需 30-60 秒，请耐心等待';
    document.getElementById('liteFallbackBtn').style.display = 'none';

    try {
        if (!StarboardEmbed) {
            const mod = await import('https://unpkg.com/starboard-wrap@0.4.2/dist/index.js');
            StarboardEmbed = mod.StarboardEmbed;
        }
        liteMode = false;
        loadNotebook(key);
    } catch (err) {
        console.error('Starboard load failed:', err);
        container.innerHTML = `
            <div style="padding:2rem;text-align:center;color:#718096;">
                <p>完整版加载失败，已切换回轻量版。</p>
            </div>
        `;
        useLiteFallback();
    }
}

function loadNotebook(key) {
    if (liteMode) {
        loadNotebookLite(key);
        return;
    }
    const container = document.getElementById('starboard-container');
    if (!container) return;

    document.getElementById('nbLoading').classList.add('hidden');
    container.innerHTML = '';

    document.querySelectorAll('.lesson-list li').forEach(li => li.classList.remove('active'));
    document.querySelectorAll('.lesson-list a').forEach(link => {
        if (link.getAttribute('onclick')?.includes(`'${key}'`)) {
            link.parentElement.classList.add('active');
        }
    });

    const notebookContent = buildNotebookContent(key);

    try {
        currentStarboard = new StarboardEmbed(container, {
            notebookContent: notebookContent,
            src: "https://cdn.starboard.gg/npm/starboard-notebook@0.15.2/dist/index.html",
            onContentUpdate: (content) => {
                console.log("Notebook updated");
            }
        });
    } catch (err) {
        console.error("Starboard init error:", err);
        useLiteFallback();
    }
}

// Expose to global for onclick handlers
window.loadNotebook = loadNotebook;
window.useLiteFallback = useLiteFallback;
window.loadFullNotebook = loadFullNotebook;

// Sidebar toggle for notebook page
document.addEventListener('DOMContentLoaded', () => {
    const menuToggle = document.getElementById('menuToggle');
    if (menuToggle) {
        menuToggle.addEventListener('click', () => {
            document.getElementById('sidebar').classList.toggle('open');
        });
    }

    initStarboard();
});
